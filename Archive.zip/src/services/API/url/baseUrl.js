export const baseUrl = 'https://transagro.pro/api'
