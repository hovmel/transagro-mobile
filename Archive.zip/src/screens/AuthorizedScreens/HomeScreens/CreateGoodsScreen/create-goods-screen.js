import React from 'react';
import {View, Text} from "react-native";
import AppWrapper from "src/components/wrapper/app-wrapper";

const CreateGoodsScreen = () => {
    return (
        <AppWrapper center title={'asdasd'}>
            <Text>Create Goods Screen</Text>
        </AppWrapper>
    );
};

export default CreateGoodsScreen;
