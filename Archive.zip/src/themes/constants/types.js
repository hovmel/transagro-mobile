export const kuzovTypes = [{title: 'Тонар'}, {title: 'Самосвал'}, {title: 'С боковой выгрузкой'}, {title: 'Сцепка'}, {title: 'Трал'}]

export const loadingTypes = [{title: 'Вертикальный'}, {title: 'Амкодор'}, {title: 'Зерномет'}, {title: 'Кун'}, {title: 'Маниту'}, {title: 'Элеватор'}, {title: 'С поля'}, {title: 'Другое'}]

export const materialTypes = [{"title":"Пшеница"},{"title":"Ячмень"},{"title":"Кукуруза"},{"title":"Горох"},{"title":"Рапс"},{"title":"Рис"},{"title":"Семечка подсолнечника"},{"title":"Нут"},{"title":"Просо"},{"title":"Отруби"},{"title":"Жмых"},{"title":"Овес"},{"title":"Соя"},{"title":"Шрот"},{"title":"Рисовая лузга"},{"title":"Свекла"},{"title":"Горчица"},{"title":"Яблоки"},{"title":"Лен"},{"title":"Жом"},{"title":"Кориандр"},{"title":"Мучка рисовая"},{"title":"Жом гранулированный"},{"title":"Барда кукурузная"},{"title":"Комбикорм"},{"title":"Удобрения"},{"title":"Сафлор"},{"title":"Семена"},{"title":"Сеннаж"}]
