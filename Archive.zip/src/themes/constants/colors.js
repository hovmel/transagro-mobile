export const COLORS = {
    textDark: '#333333',
    subTextLight: '#848484',
    invertLight: '#F2F2F2',
    globalBlue: '#4D47C7',
    inputColor: '#EDEDF9',
    green: '#64B82A',
    yellow: '#E6BA4D',
    blue: '#478CC8',
    text1: '#213F50',
    red: '#D97B7B',
    gray: '#64768A',
    black: '#000000',
    white: '#ffffff',
    inputBorder: '#C7D7EA',
    error: '#E26262'
};
